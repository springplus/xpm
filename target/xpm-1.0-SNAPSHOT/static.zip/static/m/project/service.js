/**
* Created by hongxueqian on 14-4-12.
    */

//project.factory('$$Project', ['$resource','$$MD',function($resource,$$MD) {
//    return {
//        Project:$resource($$MD.url("/api/project"), {id:"@id"},action)
//    }
//}]);

