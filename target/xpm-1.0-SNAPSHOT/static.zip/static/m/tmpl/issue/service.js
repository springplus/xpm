/**
 * Created by hongxueqian on 14-3-13.
 */

issueApp.factory("service",function(){

})