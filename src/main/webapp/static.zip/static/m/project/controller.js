/**
 * Created by hongxueqian on 14-3-3.
 */
function project($scope) {
//    $state.go('project.main')
    $scope.$parent.loadModulesMenu('project');
}