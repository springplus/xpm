var project = undefined
try {
    project= angular.module('project', ['ngGrid', 'ui.router', 'ngResource', 'xgeeUtils']);
} catch (e) {
    console.error("初始化project模块出错！", e.stack)
}

//project.config(function ($stateProvider) {
//    $stateProvider
//        .state('project', {
//            url: "/project",
//            views: {
//                "index": { templateUrl: "m/project/views/index.html" }
//            },
//            controller: 'project'
//        }).state('project.main', {
//            url: "/main",
//            views: {
//                "project": { templateUrl: "m/project/views/main.html" }
//            },
//            controller: 'project_main'
//        }).state('project.main.mixList', {
//            url: "/main_mixList",
//            views: {
//                "project_main": { templateUrl: "m/project/views/main_mixList.html" }
//            },
//            controller: 'project_main_mixList'
//        }).state('project.main.list', {
//            url: "/main_list",
//            views: {
//                "project_main": { templateUrl: "m/project/views/main_list.html" }
//            },
//            controller: 'project_main_mixList'
//        }).state('project.main.mixList.detail', {
//            url: "/detail/:item",
//            views: {
//                "project_main_mixList": { templateUrl: "m/project/views/main_mixList_detail.html" }
//            },
//            controller: 'project_main_mixList_detail'
//        })
//
//
//})
//
//


project.provider('$$projectConfig', function ($$projectForms) {
    this.logicEntity = {
        moduleName: 'project',
        resName: 'logicEntity',
        view: {
            name: 'mixListPlus',//定指该配置的解释器 //若是ngGrid，则可设置该值，类似若实现其它模板则相应的设置对象
            url: 'tmpl/base/mixListPlus',//若不填写的话，默认为 m/tmpl/{{moduleName}}/{{view.name}}
            title: '字典列表',
            query: [
                {displayName: '用户名称', name: 'name', type: 'text', rule: ['required']},
                {displayName: '登录名', name: 'login_name', type: 'text', rule: ['required']},
                {displayName: '状态', name: 'status', type: 'select', label: 'label', value: 'id', rule: ['required']}//默认select的数据来源于dict
            ],//可设置查询条件
            list: {
                onRowClick: 'update'
            },
            header: [
                {name: "id", displayName: '序号', width: "10%"},
                {name: "name", displayName: '字典项名称', width: "40%"},
                {name: "code", displayName: '字典项编码'}
            ],
            actions: [
                {name: 'create', displayName: '添加', targetContainer: 'steps', viewName: 'addLogicEntity', enable: true},
                {name: 'update', displayName: '修改', targetContainer: 'steps', viewName: 'detail', enable: true},
                {name: 'delete', displayName: '删除', targetContainer: 'none', viewName: 'detail', enable: true}
            ],
            containers: {
                tabs: [
                    {name: 'detail', title: '实体信息', active: true, template: {data: $$projectForms.logicEntityForm, dir: 'xgee'}},
                    {name: 'crudLogicField', title: '字段信息' }
                ], steps: [
                    {name: 'addLogicEntity', title: '选择物理实体', active: true},
                    {name: 'crudLogicField', title: '配置实体字段' }
                ], none: [], modal: []
            }
        }
    }

    this.$get = function () {
        return this
    };
})

project.constant('$$projectForms', {
    logicEntityForm: [
        {
            title: "名称",
            identifier: 'name',
            rules: [
                {type: 'empty', prompt: '不允许为空'}
            ]
        },
        {
            title: "编码",
            identifier: 'code',
            rules: [
                {type: 'empty', prompt: '不允许为空'}
            ]
        },
        {
            title: "描述",
            identifier: 'description',
            textarea: true
        }
    ]
})



project.config(function ($xgeeRouterProvider, $$projectConfigProvider) {
    $xgeeRouterProvider.setModuleState("project");
    $xgeeRouterProvider.setState("project.center");
    $xgeeRouterProvider.setState("project.center.index");
})


project.factory('$$projectRes', ['$resource', '$$Data', function ($Resource, $$Data) {
    return {
        //当url中已有:id时，{id:'@id'}这部分可以省略
        //-----------m.project-----------//
        project: $Resource("/api/project/:id", {id: '@id'}, $$Data.action)
    }
}]);