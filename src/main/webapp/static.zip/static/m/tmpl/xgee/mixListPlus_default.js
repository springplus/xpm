/**
 * Created by hongxq on 2014/6/12.
 */
//设置mixList模板的配置信息默认值，以及校验规则

//this.user = {
//    moduleName: 'sys',
//    resName: 'user',
//    view: {
//        name: 'mixListPlus',//定指该配置的解释器 //若是ngGrid，则可设置该值，类似若实现其它模板则相应的设置对象
//        url: 'tmpl/base/mixListPlus',//若不填写的话，默认为 m/tmpl/{{moduleName}}/{{view.name}}
//        title: '用户列表',
//        query: {},//可设置查询条件
//        header: {id: '序号', name: '用户名称', login_name: '登录账号'},
//        actions: [
//            {name: 'add', displayName: '添加', targetContainer: 'tabs', viewName: 'detail', enable: true},
//            {name: 'delete', displayName: '删除', targetContainer: 'none', viewName: 'detail', enable: true}
//        ],
//        containers: {
//            tabs: [
//                {name: 'detail', title: '概况', active: true},
//                {name: 'role', title: '角色授权' },
//                {name: 'app', title: '应用授权情况'}
//            ], steps: [], none: [], modal: []
//        }
//    }
//}