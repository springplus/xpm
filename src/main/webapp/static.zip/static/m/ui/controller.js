/**
 * Created by hongxueqian on 14-3-3.
 */
function ui($scope) {
    $scope.$parent.loadModulesMenu('ui');
}