;var views_design_select = ViewBaseCtrl.extend(function (base) {
//    this.owner = $scope[alias];
//    this.$scope = $scope[alias];
//    this.$$Data = $scope[alias];
    return {
        init: function () {
        },
        format: function (data) {

        }


    }
});