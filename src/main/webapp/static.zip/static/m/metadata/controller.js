/**
 * Created by hongxueqian on 14-3-3.
 */
function metadata($scope,$state) {
    $scope.$parent.loadModulesMenu('metadata');
}