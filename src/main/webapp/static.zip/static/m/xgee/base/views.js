/**
 * Created by hongxq on 2014/7/8.
 */


Views = {};

Views.layoutView = function(){

}

views_baseView = function() {



    // private variables : 私有属性或称为局部变量



    // private functions : 私有方法或称为局部方法



    // public space



    return {

        // public properties, e.g. strings to translate : 公有属性或称为公有变量



        // public methods : 公有方法或称为公开方法



        init : function() {

            alert('Application successfully initialized');

        }

    };

}(); //