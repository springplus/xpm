/**
 * Created by hongxueqian on 14-3-3.
 */
function report($scope) {
    $scope.$parent.loadModulesMenu('report');
}